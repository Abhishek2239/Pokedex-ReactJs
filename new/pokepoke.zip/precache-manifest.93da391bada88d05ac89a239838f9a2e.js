self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "57ebda29332cde9e63a553b51bbdeeaf",
    "url": "/index.html"
  },
  {
    "revision": "66410dc92f1d9d0e2af9",
    "url": "/static/css/main.131d46fc.chunk.css"
  },
  {
    "revision": "b54cca6793d33c93d055",
    "url": "/static/js/2.b4dd3311.chunk.js"
  },
  {
    "revision": "66410dc92f1d9d0e2af9",
    "url": "/static/js/main.55188261.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "7d7a6aa3ecd62e0897fc03ee76f202fa",
    "url": "/static/media/poke.7d7a6aa3.csv"
  }
]);